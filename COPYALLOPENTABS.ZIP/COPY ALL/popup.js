document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('copyButton').addEventListener('click', async () => {
        try {
            const tabs = await chrome.tabs.query({});
            const urls = tabs.map(tab => {
                const cleanUrl = `https://${tab.url.replace(/(^\w+:|^)\/\//, '')}`;
                const title = tab.title;
                return `${cleanUrl}\n${title}`;
            }).join('\n\n');
            await navigator.clipboard.writeText(urls);
            alert("Addresses and titles from open tabs have been copied to clipboard!");

            // Create and download the file
            const blob = new Blob([urls], {type: 'text/plain'});
            const fileUrl = URL.createObjectURL(blob);
            
            chrome.downloads.download({
                url: fileUrl,
                filename: 'tab_urls_and_titles.txt',
                saveAs: false
            }, (downloadId) => {
                chrome.downloads.open(downloadId);
            });

        } catch (error) {
            console.error('It is not possible to get a list of tabs:', error);
            alert('Error while getting the list of tabs.');
        }
    });

    document.getElementById('fileInput').addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const content = e.target.result;
                const urlRegex = /(https?:\/\/[^\s]+)/g;
                const urls = content.match(urlRegex);
                if (urls && urls.length > 0) {
                    urls.forEach(url => {
                        chrome.tabs.create({ url: url });
                    });
                    window.close(); // Close the popup
                } else {
                    alert('No valid URLs found in the file.');
                }
            };
            reader.readAsText(file);
        }
    });

    // Trigger file input when label is clicked
    document.getElementById('importLabel').addEventListener('click', () => {
        document.getElementById('fileInput').click();
    });
});